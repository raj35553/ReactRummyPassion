import { useState } from 'react'
//import reactLogo from './assets/react.svg'

import Navigation from './components/navigation';
import HeaderTitle from './components/HeaderTitle';
import AboutUs from './components/AboutUs';
import Home from './components/Home';
import './components/style.css';
import './App.css'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
  
        <Router>
        <Navigation />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/AboutUs" element={<AboutUs />} />
        </Routes>
        </Router>
  
      <HeaderTitle />
      

    </>
  )
}

export default App
