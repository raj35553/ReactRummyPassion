import React from 'react';
import PageRightSec from './PageRightSec';

const AboutUs = () => {
  return (
    <div className="container">
            <div className="row">

                <div className="col-lg-9 col-md-12"> 
                    <div className="page-left-sec">
    <div className="title">

        <div itemscope="" itemtype="http://schema.org/CreativeWork">
            <div>
                <h2 itemprop="http://schema.org/headline" className="pt-0 mt-0">The Best Online Rummy Site in India</h2>
                <p itemprop="http://schema.org/text">We are RummyPassion.com, an online rummy website for Indian players. We are fully owned and operated by Passion Gaming Private Limited, an innovative gaming company that is involved in providing the finest digital <a href="/">Rummy Games</a> to players in India. <a href="https://www.rummypassion.com/">Rummy Passion</a> is headed by experienced professionals who have worked for over 18 years in the online gaming industry. Our management team is insane <a href="/rummy-wiki/rummy-game">About Rummy</a>
                    and has an unparalleled love for the game. With 3 offices across the country and headquarters in the beautiful city of Chandigarh, India, the company has grown to over 120 employees. We are an eclectic group of focussed individuals. We are innovators, artistic designers, developers and managers who have one thing in common – <em>we live to game, we breathe gaming and we sleep gaming!</em></p>
                <p itemprop="http://schema.org/text">Should you wish to join our team, you can send an email to careers [at] passiongaming.in.</p>
            </div>
            <div>
                <h2 itemprop="http://schema.org/alternativeHeadline">Fair and Secure Gaming</h2>
                <p itemprop="http://schema.org/text">We bring you the joy of playing Rummy online on our legal website where you can create your real money account in Indian Rupees and play at any time of the day or night. We offer a Fair and Secure Game because building your trust is important to us. Your account details and gameplay will remain in complete secrecy with us. We use state of the art SSL encryption technology to protect your data and private information.</p>
            </div>
            <div>
                <h2 itemprop="http://schema.org/alternativeHeadline">Customer Support</h2>
                <p itemprop="http://schema.org/text">Besides offering you a safe and amazing rummy experience, we pride ourselves in exemplary customer service. We promise you quick and professional responses to your queries. Our friendly staff now even offers Multilanguage Customer Support during working hours. If you prefer to speak in Tamil, Telugu, Hindi, Punjabi or Kannada, our helpful customer service representatives will gladly provide you with the choice of doing so.</p>
            </div>
            <div>
                <h2 itemprop="http://schema.org/alternativeHeadline">Rummy Bonuses</h2>
                <p itemprop="http://schema.org/text">Register with Rummy Passion to receive unparalleled excitement of enriching bonuses, tournaments, competitions and VIP services so you can win prizes and cash money! Rummy Passion is a new and better way to play Rummy online or on your mobile at anytime and from anywhere. You can even meet our Latest Rummy Winners and draw some inspiration from them.</p>
            </div>
            <div>
                <h2 itemprop="http://schema.org/alternativeHeadline">Rummy Gyan Blog</h2>
                <p itemprop="http://schema.org/text">To improve the skill of players who want to get better at the game, we have created the Rummy Gyan Blog. Here you can find valuable resources like expert tips, tricks and strategies which can help you be a master of the game. You can read interesting trivia and get solid advice from reputed authors on how to play the game well. We do all this so you become better at playing and win big cash amounts.</p>
                <p itemprop="http://schema.org/text">Playing at Rummy Passion is easy. When you register with us, you get an Amazing Rummy Experience. Play for cash and claim a whopping Rs. 10,000 as bonus money in the first week of your deposits. Also, when you play for cash, you are automatically enrolled in the Passion Rewards Club, an exclusive repertoire of awards and VVIP services. Our mission is to <br />
                    <em>"Provide our players with an exhilarating online and mobile gaming experience, whatever it takes!"</em>
                </p>
            </div>

        </div>

    </div>
</div>
                </div>
   
                <div className="page-right-sec">
                    <PageRightSec />
                </div>
            </div>
    </div>
  )
}

export default AboutUs;
