//import Logo from './assets/rummy-passion-logo.webp';
//import reactLogo from '/vite.svg';
import React from 'react';
const Logo = "/images/rummy-passion-logo.webp";
import backgroundBanner from "/images/header-bg-banner.webp";
import 'bootstrap/dist/css/bootstrap.css';
import { Link } from "react-router-dom";
//style={{backgroundImage: `url(${backgroundBanner})` }}
const Navigation = () => {
    return (
      <div className="container-fluid navbar-bg" style={{backgroundImage: `url(${backgroundBanner})` }}>
        <div className="container">
            <header className="d-flex flex-wrap justify-content-center py-3 " >
              <a href="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
                <span className=""><img src={Logo} alt={"logo"} /></span>
              </a>
        
              <ul className="nav nav-pills nav-custom">
                <li className="nav-item">
                
                  <Link to={"/Home"} className="nav-link">
                    Home
                  </Link>
                  </li>
                <li className="nav-item">
                  <Link to={"/AboutUs"} className="nav-link">
                     About Us
                  </Link>
                  </li>
                <li className="nav-item">
                  <a href="#" className="nav-link">How to play rummy</a>
                  </li>
                <li className="nav-item">
                  <a href="#" className="nav-link">Promotions</a>
                  </li>
                <li className="nav-item">
                  <a href="#" className="nav-link">RummyGyan</a>
                  </li>
                <li className="nav-item">
                  <a href="#" className="nav-link">Contact Us</a>
                  </li>
              </ul>
            </header>
          </div>
      </div>
    );
}

export default Navigation;