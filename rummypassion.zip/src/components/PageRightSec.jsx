import React from 'react';
import Sidebarbanner1 from "/images/welcome-sidebar-banner.webp";
import Sidebarbanner2 from "/images/top-up-bonus-3000-n.webp";

const PageRightSec = () => {
  return (
    <div class="page-right-sec">
   <div class="banner-sec">
      <a href="/promotions/welcome-bonus"><img width="320" height="493" src={Sidebarbanner1} loading="lazy" class="img-fluid" alt="Get Rs. 7000 Welcome Bonus at RummyPassion" title="Get Rs. 7000 Welcome Bonus at RummyPassion" /></a>
  
      <a href="/promotions/top-up-bonus"> <img width="320" height="493" src={Sidebarbanner2} loading="lazy" class="img-fluid" alt="Get Rs. 3000 Top Up Bonus at RummyPassion" title="Get Rs. 3000 Top Up Bonus at RummyPassion" /></a>

   </div>
   <div class="quick-link-right-wrapper">
      <h5>Rummy Passion Quick Guide</h5>
      <ul>
         <li><a href="/how-to-play-rummy">Learn to Play Rummy Online</a></li>
         <li><a href="/rummy-wiki">Rummy Wiki</a></li>
         <li><a href="/legal-in-india">Is Rummy Game Legal in India?</a></li>
         <li><a href="/play-indian-rummy">Why Play Indian Rummy?</a></li>
         <li><a href="/safe-and-secure">Is it Safe to Play Rummy Online?</a></li>
         <li><a href="/payments-and-withdrawals">Deposits and Withdrawal</a></li>
         <li><a href="/types-of-rummy-variations">Types of Indian Rummy Variations?</a></li>
         <li><a href="/classic-13-cards-rummy-rules">What are Classic Rummy Rules?</a></li>
         <li><a href="/classic-13-cards-rummy-rules/points-rummy">13 Card Points Rummy Rules</a></li>
         <li><a href="/classic-13-cards-rummy-rules/pool-rummy">13 Card Pool Rummy Rules</a></li>
         <li><a href="/classic-13-cards-rummy-rules/deals-rummy">13 Card Deals Rummy Rules</a></li>
         <li><a href="/rummy-cash-games">How to Play Rummy Cash Games?</a></li>
      </ul>
   </div>
</div>
  )
}

export default PageRightSec;