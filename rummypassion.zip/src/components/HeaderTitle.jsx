import TitleBanner from "/images/title-bg-banner-1320.webp";
const HeaderTitle = () => {
    return (
      <div className="container-fluid page-title-bg" style={{backgroundImage: `url(${TitleBanner})` }}>
      
            <div class="container">
                <div class="row">
                   
                        <h1>ABOUT RUMMY PASSION</h1>
                  
                </div>
            </div>
       
      </div>
    );
}

export default HeaderTitle;